STUDIO RIDER RECEIVER 0.3 - PROTOTIPO DE RECEPCION FLAC (macOS/Apple Silicon)
=============================================================================

Este proyecto se basa en el VST3 de diagnostico que ya probaste.
Implementa una conexion nativa WebSocket al protocolo MXS2 de StudioRider 1.0:
  https://github.com/Creme74/StudioRider/releases/tag/v1.0

NO ES AUN UNA VERSION VALIDADA DE PRODUCCION:
- Fuente revisada estructuralmente, pero NO compilada ni escuchada en macOS en este entorno.
- FLAC 16 y 24 bits segun la calidad del emisor; pide ?q=hires.
- El flujo se entrega a processBlock() sin salida directa a CoreAudio.
- Mantiene tono de 1 kHz para comprobacion.
- No incluye Opus; si el emisor limita a Opus eco, avisara en pantalla.
- Buffer 500ms y resampleo lineal si se transmiten tasas distintas. Para comparar
  mezclas de manera critica usa preferentemente igual sample rate (ideal 48kHz)
  y evalua una version posterior con resampleo de mayor calidad.
- Sin reconexion automatica y sin manejo completo de cambios de calidad.
- El decoder dr_flac se obtiene desde GitHub al configurar CMake.

REQUISITOS
macOS 15.5 ya compatible, CLT 16.4, CMake 4.4, Git, internet.
No es necesario actualizar macOS ni instalar Xcode completo.

COMPILAR (una orden por paso, sin copiar el texto de salida):
  /opt/homebrew/bin/cmake -S "$HOME/Desktop/StudioRiderReceiver-network" -B "$HOME/Desktop/StudioRiderReceiver-network/build" -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=arm64

  /opt/homebrew/bin/cmake --build "$HOME/Desktop/StudioRiderReceiver-network/build" --config Release --parallel 4

No copies el VST3 ni lo pruebes en produccion hasta que compile sin errores.
Una vez compilado, instala el nuevo .vst3 en la carpeta del usuario como en la version 0.2,
reinicia Pro Tools y carga en Blue Cat PatchWork.

USO
1. Emisor: StudioRider 1.0 compartiendo en calidad CD o Hi-Res.
2. Receptor: pega su enlace de escucha de trycloudflare.com y pulsa Conectar.
3. Deja sonando el emisor 1 segundo o mas; el VST3 necesita buffer inicial.
4. Aplica EQ en el mismo PatchWork despues del receptor.
5. Si no funciona, envia el error del compilador o el mensaje de estado; no
   actualices macOS ni desinstales el plugin anterior.

AUTORIA Y LICENCIAS
El protocolo esta documentado en el proyecto StudioRider, GPL-3.0-or-later.
Este prototipo es una implementacion propia del cliente del protocolo, sin
copiar codigo fuente de StudioRider. dr_flac por David Reid, dominio publico o MIT-0.
JUCE se obtiene desde juce-framework/JUCE con licencia propia (GPL/comercial).
Revisa las licencias aplicables antes de redistribuir o comercializar binarios.
