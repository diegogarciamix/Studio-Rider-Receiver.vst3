#include "PluginEditor.h"
#include <algorithm>

StudioRiderReceiverAudioProcessorEditor::StudioRiderReceiverAudioProcessorEditor(
    StudioRiderReceiverAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(640, 315);

    urlInput.setTextToShowWhenEmpty("Pega tu enlace HTTPS de StudioRider 1.0...", juce::Colours::grey);
    urlInput.setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xff20242b));
    urlInput.setColour(juce::TextEditor::textColourId, juce::Colours::white);
    urlInput.setColour(juce::TextEditor::outlineColourId, juce::Colour(0xff3c424c));
    addAndMakeVisible(urlInput);

    checkButton.setButtonText("Conectar");
    checkButton.onClick = [this]
    {
        auto& client = audioProcessor.getStreamClient();
        if (client.isConnected()) client.disconnect();
        else client.connectToUrl(urlInput.getText());
    };
    addAndMakeVisible(checkButton);

    testToneButton.setColour(juce::ToggleButton::textColourId, juce::Colours::white);
    addAndMakeVisible(testToneButton);
    testToneAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        audioProcessor.apvts, "testTone", testToneButton);

    gainSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    gainSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 22);
    gainSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff22d3ee));
    gainSlider.setColour(juce::Slider::trackColourId, juce::Colour(0xff0891b2));
    addAndMakeVisible(gainSlider);
    gainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        audioProcessor.apvts, "gain", gainSlider);

    muteButton.setColour(juce::ToggleButton::textColourId, juce::Colours::white);
    addAndMakeVisible(muteButton);
    muteAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        audioProcessor.apvts, "mute", muteButton);

    statusLabel.setJustificationType(juce::Justification::centredLeft);
    statusLabel.setColour(juce::Label::textColourId, juce::Colour(0xffa8bbc6));
    statusLabel.setText(audioProcessor.getStreamClient().getStatusMessage(), juce::dontSendNotification);
    addAndMakeVisible(statusLabel);
    startTimerHz(20);
}

StudioRiderReceiverAudioProcessorEditor::~StudioRiderReceiverAudioProcessorEditor()
{
    stopTimer();
}

void StudioRiderReceiverAudioProcessorEditor::timerCallback()
{
    statusLabel.setText(audioProcessor.getStreamClient().getStatusMessage(), juce::dontSendNotification);
    currentMeter = currentMeter * 0.75f + audioProcessor.getOutputMeter() * 0.25f;
    checkButton.setButtonText(audioProcessor.getStreamClient().isConnected() ? "Desconectar" : "Conectar");
    repaint();
}

void StudioRiderReceiverAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff141820));
    g.setColour(juce::Colours::white);
    g.setFont(19.0f);
    g.drawText("STUDIO RIDER RECEIVER", 24, 16, 380, 27, juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xfff1c96b));
    g.setFont(12.0f);
    g.drawText("RECEPTOR NATIVO EXPERIMENTAL · FLAC 16/24 BITS", 24, 43, 580, 21,
               juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xffa8bbc6));
    g.setFont(13.0f);
    g.drawText("Conecta un enlace de StudioRider 1.0. Audio al buffer de Pro Tools.",
               24, 75, 590, 20, juce::Justification::centredLeft);
    g.drawText("Nivel de salida", 24, 202, 140, 20, juce::Justification::centredLeft);

    const int meterX = 24;
    const int meterY = 281;
    const int meterWidth = getWidth() - 48;
    const int meterHeight = 12;
    g.setColour(juce::Colour(0xff2b3038));
    g.fillRoundedRectangle(static_cast<float>(meterX), static_cast<float>(meterY),
                           static_cast<float>(meterWidth), static_cast<float>(meterHeight), 4.0f);
    const float fillWidth = std::clamp(currentMeter, 0.0f, 1.0f) * static_cast<float>(meterWidth);
    if (fillWidth > 0.0f)
    {
        g.setColour(currentMeter > 0.95f ? juce::Colours::red : juce::Colour(0xff22d3ee));
        g.fillRoundedRectangle(static_cast<float>(meterX), static_cast<float>(meterY),
                               fillWidth, static_cast<float>(meterHeight), 4.0f);
    }
}

void StudioRiderReceiverAudioProcessorEditor::resized()
{
    urlInput.setBounds(24, 107, 440, 33);
    checkButton.setBounds(473, 107, 143, 33);
    testToneButton.setBounds(24, 151, 360, 28);
    gainSlider.setBounds(150, 199, 366, 30);
    muteButton.setBounds(538, 199, 79, 30);
    statusLabel.setBounds(24, 245, 592, 26);
}
