// Studio Rider Receiver: experimental native FLAC client for StudioRider v1.0.
// Protocol: https://github.com/Creme74/StudioRider (GPL-3.0-or-later).
// No StudioRider source code is copied here: wire format implemented independently.
#define DR_FLAC_IMPLEMENTATION
#include "dr_flac.h"
#include "StreamClient.h"
#import <Foundation/Foundation.h>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

struct SRSharedState
{
    static constexpr uint64_t capacity = 1u << 18; // at least 5s of stereo @48k
    std::vector<float> audio = std::vector<float>(capacity * 2, 0.0f);
    std::atomic<uint64_t> write { 0 }, read { 0 };
    std::atomic<unsigned int> epoch { 0 };
    std::atomic<int> sourceRate { 48000 };
    std::atomic<double> hostRate { 48000.0 };
    std::atomic<bool> alive { true }, connected { false };
    mutable std::mutex statusMutex;
    std::string status { "Pega un enlace de StudioRider 1.0 y pulsa Conectar." };

    void setStatus(const std::string& s)
    {
        std::lock_guard<std::mutex> lock(statusMutex);
        status = s;
    }
    void appendPcm(const float* pcm, uint64_t frames)
    {
        // Single producer (sequential NSURLSession WebSocket receive callbacks).
        if (!pcm || frames == 0 || frames >= capacity) return;
        const auto w = write.load(std::memory_order_relaxed);
        const auto r = read.load(std::memory_order_acquire);
        if (w - r + frames >= capacity) return; // drop new frame if receiver is too slow
        for (uint64_t i = 0; i < frames; ++i)
        {
            const auto pos = ((w + i) % capacity) * 2;
            audio[pos] = pcm[i * 2];
            audio[pos + 1] = pcm[i * 2 + 1];
        }
        write.store(w + frames, std::memory_order_release);
    }
};

static uint32_t readLE32(const uint8_t* p)
{
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

static bool decodeFlacFrame(const uint8_t* payload, size_t size, int rate, int bits,
                            uint32_t announcedFrames, SRSharedState& state)
{
    if (bits != 16 && bits != 24) return false;
    if (rate < 8000 || rate > 192000 || !announcedFrames || announcedFrames > 8192 || !size) return false;

    // StudioRider transmits a raw FLAC FRAME (not an .flac file).
    // Reconstruct a minimal FLAC stream header + STREAMINFO before decoding it.
    // 4 bytes signature + 4 bytes metadata block header + 34 STREAMINFO bytes.
    std::vector<uint8_t> frame(42 + size, 0);
    frame[0] = 'f'; frame[1] = 'L'; frame[2] = 'a'; frame[3] = 'C';
    frame[4] = 0x80; // final metadata block, type STREAMINFO
    frame[7] = 34;
    frame[8] = 0; frame[9] = 16; // min blocksize
    frame[10] = 0x20; frame[11] = 0x00; // max blocksize 8192
    const uint64_t packed = (uint64_t(rate) << 44) | (uint64_t(1) << 41)
                          | (uint64_t(bits - 1) << 36);
    for (int i = 0; i < 8; ++i)
        frame[18 + i] = uint8_t(packed >> (56 - i * 8));
    std::memcpy(frame.data() + 42, payload, size);

    drflac* f = drflac_open_memory(frame.data(), frame.size(), nullptr);
    if (!f) return false;
    const auto nToRead = std::min<uint64_t>(announcedFrames, 8192);
    std::vector<float> pcm(nToRead * 2);
    const auto n = drflac_read_pcm_frames_f32(f, nToRead, pcm.data());
    const bool isStereo = f->channels == 2;
    drflac_close(f);
    if (!isStereo || n == 0) return false;
    state.sourceRate.store(rate, std::memory_order_relaxed);
    state.appendPcm(pcm.data(), n);
    return true;
}

@interface SRSocketBridge : NSObject
{
@public
    std::shared_ptr<SRSharedState> sharedState;
    unsigned int requestEpoch;
}
@property(nonatomic, strong) NSURLSession* session;
@property(nonatomic, strong) NSURLSessionWebSocketTask* socket;
- (instancetype)initWithState:(std::shared_ptr<SRSharedState>)s;
- (void)connect:(NSString*)urlText;
- (void)disconnect;
- (void)receiveNext:(NSURLSessionWebSocketTask*)task epoch:(unsigned int)epoch;
- (void)heartbeat:(NSURLSessionWebSocketTask*)task epoch:(unsigned int)epoch;
@end

@implementation SRSocketBridge
- (instancetype)initWithState:(std::shared_ptr<SRSharedState>)s
{
    if ((self = [super init])) { sharedState = std::move(s); requestEpoch = 0; }
    return self;
}
- (void)disconnect
{
    ++requestEpoch;
    sharedState->connected.store(false);
    if (self.socket)
        [self.socket cancelWithCloseCode:NSURLSessionWebSocketCloseCodeNormalClosure reason:nil];
    self.socket = nil;
    if (self.session) [self.session invalidateAndCancel];
    self.session = nil;
    sharedState->epoch.fetch_add(1);
}
- (void)connect:(NSString*)urlText
{
    [self disconnect];
    NSURLComponents* u = [NSURLComponents componentsWithString:[urlText stringByTrimmingCharactersInSet:
                                                                  [NSCharacterSet whitespaceAndNewlineCharacterSet]]];
    NSString* scheme = u.scheme.lowercaseString;
    if (!u || !u.host || !([scheme isEqualToString:@"https"] || [scheme isEqualToString:@"http"]))
    {
        sharedState->setStatus("URL incorrecta: pega el enlace HTTPS de escucha.");
        return;
    }
    if ([scheme isEqualToString:@"http"] && !([u.host isEqualToString:@"127.0.0.1"] ||
                                                [u.host isEqualToString:@"localhost"]))
    {
        sharedState->setStatus("Solo se permite HTTP para localhost. Usa HTTPS.");
        return;
    }
    NSString* path = u.path ?: @"";
    if (![path hasSuffix:@"/"]) path = [path stringByAppendingString:@"/"];
    if ([path isEqualToString:@"/"])
    {
        sharedState->setStatus("Enlace incompleto: falta el token de escucha.");
        return;
    }
    u.path = [path stringByAppendingString:@"ws"];
    u.query = @"q=hires"; // maximum quality allowed by the sender: FLAC 24/16, or Opus-only
    u.fragment = nil;
    u.scheme = [scheme isEqualToString:@"https"] ? @"wss" : @"ws";
    NSURL* wsURL = u.URL;
    if (!wsURL) { sharedState->setStatus("No se pudo construir la URL WebSocket."); return; }

    sharedState->setStatus("Conectando a StudioRider (FLAC 16/24 bits)...");
    NSURLSessionConfiguration* config = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    config.timeoutIntervalForRequest = 15;
    self.session = [NSURLSession sessionWithConfiguration:config];
    self.socket = [self.session webSocketTaskWithURL:wsURL];
    NSURLSessionWebSocketTask* task = self.socket;
    const auto epoch = requestEpoch;
    [task resume];
    [self receiveNext:task epoch:epoch];
    [self heartbeat:task epoch:epoch];
}
- (void)heartbeat:(NSURLSessionWebSocketTask*)task epoch:(unsigned int)epoch
{
    // Keep the WebSocket alive when the studio's transport is stopped.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)),
                   dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        if (epoch != self->requestEpoch || !self->sharedState->alive.load()) return;
        [task sendMessage:[[NSURLSessionWebSocketMessage alloc] initWithString:@"ka"]
           completionHandler:^(NSError* error) { (void)error; }];
        [self heartbeat:task epoch:epoch];
    });
}
- (void)receiveNext:(NSURLSessionWebSocketTask*)task epoch:(unsigned int)epoch
{
    [task receiveMessageWithCompletionHandler:^(NSURLSessionWebSocketMessage* msg, NSError* error) {
        if (epoch != self->requestEpoch || !self->sharedState->alive.load()) return;
        if (error || !msg)
        {
            self->sharedState->connected.store(false);
            self->sharedState->setStatus("Conexión interrumpida. Pulsa Conectar para reintentar.");
            return;
        }
        if (msg.type == NSURLSessionWebSocketMessageTypeString)
        {
            NSString* body = msg.string;
            if ([body containsString:@"\"type\":\"bye\""])
            {
                self->sharedState->connected.store(false);
                self->sharedState->setStatus("La emisión ha terminado. Solicita un enlace nuevo.");
                return;
            }
            if ([body containsString:@"\"type\":\"info\""])
            {
                self->sharedState->connected.store(true);
                if ([body containsString:@"\"maxQuality\":\"eco\""])
                    self->sharedState->setStatus("Emisor en modo Opus: este prototipo solo admite FLAC.");
                else
                    self->sharedState->setStatus("Conectado. Esperando audio FLAC...");
            }
        }
        else if (msg.type == NSURLSessionWebSocketMessageTypeData)
        {
            NSData* d = msg.data;
            if (d.length >= 21)
            {
                const uint8_t* p = (const uint8_t*) d.bytes;
                if (memcmp(p, "MXS2", 4) == 0)
                {
                    const int codec = p[4];
                    const int channels = p[5];
                    const int bits = p[6];
                    const int rate = (int)readLE32(p + 8);
                    const uint32_t frames = readLE32(p + 12);
                    if (codec == 2 && channels == 2)
                    {
                        if (decodeFlacFrame(p + 20, d.length - 20, rate, bits, frames,
                                            *self->sharedState))
                        {
                            self->sharedState->connected.store(true);
                            self->sharedState->setStatus("Recibiendo FLAC estéreo; audio en Pro Tools.");
                        }
                        else self->sharedState->setStatus("Recibiendo FLAC, error al decodificar paquete.");
                    }
                    else if (codec == 3)
                        self->sharedState->setStatus("Emisión Opus: pendiente de implementar.");
                }
            }
        }
        [self receiveNext:task epoch:epoch];
    }];
}
@end

StreamClient::StreamClient() : shared(std::make_shared<SRSharedState>())
{
    SRSocketBridge* b = [[SRSocketBridge alloc] initWithState:shared];
    bridge = (__bridge_retained void*) b;
}
StreamClient::~StreamClient()
{
    shared->alive.store(false);
    SRSocketBridge* b = (__bridge_transfer SRSocketBridge*) bridge;
    [b disconnect];
    bridge = nullptr;
}
void StreamClient::connectToUrl(const juce::String& url)
{
    auto* b = (__bridge SRSocketBridge*) bridge;
    [b connect:[NSString stringWithUTF8String:url.toRawUTF8()]];
}
void StreamClient::disconnect()
{
    auto* b = (__bridge SRSocketBridge*) bridge;
    [b disconnect];
    shared->setStatus("Desconectado.");
}
juce::String StreamClient::getStatusMessage() const
{
    std::lock_guard<std::mutex> lock(shared->statusMutex);
    return juce::String::fromUTF8(shared->status.c_str());
}
bool StreamClient::isConnected() const noexcept { return shared->connected.load(); }
void StreamClient::setHostSampleRate(double r) noexcept
{
    if (r > 0) shared->hostRate.store(r, std::memory_order_relaxed);
}
void StreamClient::render(float* L, float* R, int frames) noexcept
{
    if (frames <= 0) return;
    auto& s = *shared;
    const auto epoch = s.epoch.load(std::memory_order_relaxed);
    if (lastEpoch != epoch)
    {
        lastEpoch = epoch;
        s.read.store(s.write.load(std::memory_order_acquire), std::memory_order_release);
        fractionalPos = 0;
        playing = false;
        fade = 0;
    }
    auto r = s.read.load(std::memory_order_relaxed);
    const auto w = s.write.load(std::memory_order_acquire);
    const int srcRate = s.sourceRate.load(std::memory_order_relaxed);
    const double hostRate = s.hostRate.load(std::memory_order_relaxed);
    const double ratio = (hostRate > 0) ? double(srcRate) / hostRate : 1.0;
    constexpr uint64_t cap = SRSharedState::capacity;
    const uint64_t target = std::max<uint64_t>(4096, (uint64_t)(srcRate * 0.5));
    if (!playing && w - r >= target)
    {
        playing = true;
        fade = 240;
    }
    if (w > r + srcRate * 2u) // trim excessive latency after network hiccups
    {
        r = w - target;
        fractionalPos = 0;
    }
    for (int i = 0; i < frames; ++i)
    {
        if (!playing || w <= r + 1)
        {
            playing = false;
            L[i] = R[i] = 0.0f;
            continue;
        }
        const auto a = (r % cap) * 2;
        const auto b = ((r + 1) % cap) * 2;
        float l = (float)((1 - fractionalPos) * s.audio[a] + fractionalPos * s.audio[b]);
        float rr = (float)((1 - fractionalPos) * s.audio[a + 1] + fractionalPos * s.audio[b + 1]);
        if (fade > 0) { const float g = 1.0f - float(fade) / 240.0f; l *= g; rr *= g; --fade; }
        L[i] = l; R[i] = rr;
        fractionalPos += ratio;
        const uint64_t advance = (uint64_t) fractionalPos;
        r += advance;
        fractionalPos -= double(advance);
    }
    s.read.store(r, std::memory_order_release);
}
