#pragma once
#include <juce_core/juce_core.h>
#include <memory>

// StudioRider v1.0: native WebSocket + FLAC receiver. No embedded web browser.
// Audio data is decoded on the URLSession callback thread, never on the DAW audio thread.
struct SRSharedState;

class StreamClient final
{
public:
    StreamClient();
    ~StreamClient();
    void connectToUrl(const juce::String& url);
    void disconnect();
    juce::String getStatusMessage() const;
    void setHostSampleRate(double rate) noexcept;
    void render(float* left, float* right, int frames) noexcept;
    bool isConnected() const noexcept;

private:
    std::shared_ptr<SRSharedState> shared;
    void* bridge = nullptr; // ARC-retained SRSocketBridge object (StreamClient.mm)
    double fractionalPos = 0.0; // audio thread only
    bool playing = false;       // audio thread only
    int fade = 0;               // audio thread only
    unsigned int lastEpoch = 0; // audio thread only
};
