#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <atomic>
#include "StreamClient.h"

class StudioRiderReceiverAudioProcessor final : public juce::AudioProcessor
{
public:
    StudioRiderReceiverAudioProcessor();
    ~StudioRiderReceiverAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Studio Rider Receiver"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    StreamClient& getStreamClient() noexcept { return streamClient; }
    float getOutputMeter() const noexcept { return outputMeter.load(std::memory_order_relaxed); }
    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    StreamClient streamClient;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> gainSmoother;
    std::atomic<float> outputMeter { 0.0f };
    double currentSampleRate = 48000.0;
    double oscillatorPhase = 0.0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioRiderReceiverAudioProcessor)
};
