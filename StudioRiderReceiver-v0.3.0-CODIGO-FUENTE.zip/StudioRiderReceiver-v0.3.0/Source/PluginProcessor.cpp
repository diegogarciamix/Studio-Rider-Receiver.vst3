#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>

StudioRiderReceiverAudioProcessor::StudioRiderReceiverAudioProcessor()
    : AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout
StudioRiderReceiverAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "gain", 1 }, "Output Gain",
        juce::NormalisableRange<float>(-60.0f, 12.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")));
    layout.add(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "mute", 1 }, "Mute", false));
    layout.add(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "testTone", 1 }, "Diagnostic Tone 1 kHz", false));
    return layout;
}

void StudioRiderReceiverAudioProcessor::prepareToPlay(double sampleRate, int)
{
    currentSampleRate = sampleRate > 0.0 ? sampleRate : 48000.0;
    streamClient.setHostSampleRate(currentSampleRate);
    oscillatorPhase = 0.0;
    gainSmoother.reset(currentSampleRate, 0.02);
    gainSmoother.setCurrentAndTargetValue(1.0f);
    outputMeter.store(0.0f, std::memory_order_relaxed);
}

bool StudioRiderReceiverAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        && layouts.getMainInputChannelSet() == juce::AudioChannelSet::stereo();
}

void StudioRiderReceiverAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                                     juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    const int numSamples = buffer.getNumSamples();
    if (buffer.getNumChannels() < 2 || numSamples == 0)
    {
        outputMeter.store(0.0f, std::memory_order_relaxed);
        return;
    }

    const bool muted = apvts.getRawParameterValue("mute")->load(std::memory_order_relaxed) > 0.5f;
    const bool testTone = apvts.getRawParameterValue("testTone")->load(std::memory_order_relaxed) > 0.5f;
    const float gainDb = apvts.getRawParameterValue("gain")->load(std::memory_order_relaxed);
    gainSmoother.setTargetValue(muted ? 0.0f : juce::Decibels::decibelsToGain(gainDb));

    float* left = buffer.getWritePointer(0);
    float* right = buffer.getWritePointer(1);
    const double phaseIncrement = juce::MathConstants<double>::twoPi * 1000.0 / currentSampleRate;
    constexpr float toneAmplitude = 0.0630957f; // -24 dBFS peak
    float peak = 0.0f;

    if (!testTone)
        streamClient.render(left, right, numSamples);

    for (int i = 0; i < numSamples; ++i)
    {
        const float toneSample = testTone ? toneAmplitude * static_cast<float>(std::sin(oscillatorPhase)) : 0.0f;
        oscillatorPhase += phaseIncrement;
        if (oscillatorPhase >= juce::MathConstants<double>::twoPi)
            oscillatorPhase -= juce::MathConstants<double>::twoPi;

        const float gain = gainSmoother.getNextValue();
        left[i] = (left[i] + toneSample) * gain;
        right[i] = (right[i] + toneSample) * gain;
        peak = std::max(peak, std::max(std::abs(left[i]), std::abs(right[i])));
    }
    outputMeter.store(peak, std::memory_order_relaxed);
}

juce::AudioProcessorEditor* StudioRiderReceiverAudioProcessor::createEditor()
{
    return new StudioRiderReceiverAudioProcessorEditor(*this);
}

void StudioRiderReceiverAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, destData);
}

void StudioRiderReceiverAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName(apvts.state.getType()))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new StudioRiderReceiverAudioProcessor();
}
