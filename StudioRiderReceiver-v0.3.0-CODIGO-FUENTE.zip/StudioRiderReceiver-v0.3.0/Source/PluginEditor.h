#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include <memory>

class StudioRiderReceiverAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                     private juce::Timer
{
public:
    explicit StudioRiderReceiverAudioProcessorEditor(StudioRiderReceiverAudioProcessor&);
    ~StudioRiderReceiverAudioProcessorEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    StudioRiderReceiverAudioProcessor& audioProcessor;
    juce::TextEditor urlInput;
    juce::TextButton checkButton { "Comprobar URL" };
    juce::ToggleButton testToneButton { "Generar tono de prueba 1 kHz" };
    juce::Slider gainSlider;
    juce::ToggleButton muteButton { "MUTE" };
    juce::Label statusLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> muteAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> testToneAttachment;
    float currentMeter = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioRiderReceiverAudioProcessorEditor)
};
